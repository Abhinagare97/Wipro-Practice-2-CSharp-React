
import './App.css';
import AddUsers from './components/AddUsers';
import ShowUsers from './components/ShowUsers';

function App() {
  return (
    <div>
    <ShowUsers/><br/>
    <AddUsers/>
    </div>
  );
}

export default App;
