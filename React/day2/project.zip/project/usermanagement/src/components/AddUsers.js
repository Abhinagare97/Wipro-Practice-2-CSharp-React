import { useState } from "react";
import axios from "axios";

const AddUsers = () => {
    const [User, setUser] = useState({
        id: 0,
        name: "",
        address: ""
    });

    const handleChange = (event) => {
        setUser({
            ...User,
            [event.target.name]: event.target.value
        });
    };

    const addEmployee = () => {
        axios.post("http://localhost:4000/adduser", {
            id: User.id,
            name: User.name,
            address: User.address
        }).then(resp => {
            console.log(resp.data);
        });
    };

    return (

        
        <div align ="center"> 
        <h2>Add Users</h2>
            <label>Id</label>
            <input 
                type="number" 
                name="id" 
                value={User.id} 
                onChange={handleChange} 
            /> <br/>

            <label>Name</label>
            <input 
                type="text" 
                name="name" 
                value={User.name} 
                onChange={handleChange} 
            /> <br/>

            <label>Address</label>
            <input 
                type="text" 
                name="address" 
                value={User.address} 
                onChange={handleChange} 
            /> <br/>

            <input type="button" value="Add Employee" onClick={addEmployee} />
        </div>
    );
};

export default AddUsers;
