import { useState, useEffect } from "react";
import axios from "axios";

const ShowUsers = () => {
    const [user, setUser] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get("http://localhost:4000/");
                setUser(response.data);
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };
        fetchData();
    }, []);

    return (
        <div align="center">
        <h2>User Management System</h2>
        <h2>Users</h2>
        <table border="2" align="center">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
         {user.map((item) => 
                        <tr key={item.id}>
                            <td>{item.id}</td>
                            <td>{item.name}</td>
                            <td>{item.address}</td>
                        </tr>
                    )}
            </tbody>
        </table>
        </div>
    );
};

export default ShowUsers;
